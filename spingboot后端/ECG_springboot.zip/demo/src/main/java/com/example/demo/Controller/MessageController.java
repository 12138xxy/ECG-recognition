package com.example.demo.Controller;

import com.example.demo.dao.MessageMapper;
import com.example.demo.model.Message;
import com.example.demo.model.MessageDTO;
import com.example.demo.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/messages")
public class MessageController {
    private final MessageMapper messageMapper;

    private final MessageService messageService;



    @Autowired
    public MessageController(MessageService messageService, MessageMapper messageMapper) {
        this.messageService = messageService;
        this.messageMapper = messageMapper;
    }

    // 获取所有消息
    @GetMapping("/between")
    public List<Message> getMessagesBetweenUsers(@RequestParam String user1, @RequestParam String user2) {
        messageMapper.updateMessagesState(user1, user2);
        return messageMapper.findMessagesBetweenUsers(user1, user2);
    }

    // 发送新消息
    @PostMapping
    public ResponseEntity<Void> postMessage(@RequestBody Message message) {
        messageMapper.insertMessage(message);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{receiver}")
    public List<MessageDTO> getUserMessages(@PathVariable String receiver) {
        return messageService.getUserMessages(receiver);
    }
}
