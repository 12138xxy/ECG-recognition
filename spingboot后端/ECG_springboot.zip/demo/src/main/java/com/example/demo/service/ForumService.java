package com.example.demo.service;

import com.example.demo.dao.ForumMapper;
import com.example.demo.model.Comment;
import com.example.demo.model.Doctor;
import com.example.demo.model.Like;
import com.example.demo.model.UserForum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ForumService {

    private final ForumMapper forumMapper;
    private List<UserForum> data;

    @Autowired
    public ForumService(ForumMapper forumMapper){this.forumMapper = forumMapper;}

    public boolean showForum(UserForum newUserForum){
        int count = forumMapper.countByAccount(newUserForum.getUsername());
        if(count == 0){ //有评论内容
            System.out.println("暂时没有评论");
            return false;
        }

        return true;
    }

    public String getNickname(String username){
        return forumMapper.GetNickname(username);
    }

    public void insertForum(UserForum userForum){
        forumMapper.insert(userForum);
    }

    public List<UserForum> getData(){
        List<UserForum> data = forumMapper.getContent();
        //System.out.println(data.get(0));
        return forumMapper.getContent();
    }

    public void updateLike(Like like){
        if(forumMapper.checkLikeStatus(like.getPostId(), like.getUsername()) == 0) {
            forumMapper.insertLike1(like);
            forumMapper.updateLike(like.getPostId());}
        else{
            forumMapper.insertLike2(like);
            forumMapper.updateLike2(like.getPostId());
        }
    }

    public UserForum getForumById(int id) {
        return forumMapper.selectForumById(id);
    }

    public boolean isPostLikedByUser(int postId, String username) {
        return forumMapper.checkLikeStatus(postId, username) > 0;
    }

    public List<Comment> getCommentsByPostId(int postId) {
        return forumMapper.findAllByPostId(postId);
    }

    public void addComment(Comment comment) {
        forumMapper.addComment(comment);
        forumMapper.updateComment(comment.id_forum);
    }

    public List<UserForum> searchByContent(String content) {
        return forumMapper.searchByContent(content);
    }

}
