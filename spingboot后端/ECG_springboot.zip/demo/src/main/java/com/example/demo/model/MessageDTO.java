package com.example.demo.model;

import java.time.LocalDateTime;

public class MessageDTO {
    private String sender;
    private Long latestMessageTimestamp;
    private String latestMessageContent;
    private Long unreadCount;

    // 构造方法
    public MessageDTO(String sender, Long latestMessageTimestamp, String latestMessageContent, Long unreadCount) {
        this.sender = sender;
        this.latestMessageTimestamp = latestMessageTimestamp;
        this.latestMessageContent = latestMessageContent;
        this.unreadCount = unreadCount;
    }

    // getters 和 setters
    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public Long getLatestMessageTimestamp() {
        return latestMessageTimestamp;
    }

    public void setLatestMessageTimestamp(Long latestMessageTimestamp) {
        this.latestMessageTimestamp = latestMessageTimestamp;
    }

    public String getLatestMessageContent() {
        return latestMessageContent;
    }

    public void setLatestMessageContent(String latestMessageContent) {
        this.latestMessageContent = latestMessageContent;
    }

    public Long getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(Long unreadCount) {
        this.unreadCount = unreadCount;
    }
}
