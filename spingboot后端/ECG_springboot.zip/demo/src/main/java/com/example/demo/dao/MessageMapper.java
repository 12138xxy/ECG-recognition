package com.example.demo.dao;

import com.example.demo.model.Message;
import com.example.demo.model.MessageDTO;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface MessageMapper {
    // 插入新消息
    @Insert("INSERT INTO message_table (sender, receiver, content, timestamp, state) VALUES (#{sender}, #{receiver}, #{content}, #{timestamp}, 0)")
    void insertMessage(Message message);

    @Select("SELECT * FROM message_table WHERE (sender = #{user1} AND receiver = #{user2}) OR (sender = #{user2} AND receiver = #{user1}) ORDER BY timestamp ASC")
    List<Message> findMessagesBetweenUsers(@Param("user1") String user1, @Param("user2") String user2);

    @Update("UPDATE message_table SET state = 1 WHERE (sender = #{user2} AND receiver = #{user1})")
    void updateMessagesState(@Param("user1") String user1, @Param("user2") String user2);

    @Select("SELECT \n" +
            "    ContactUser.contact_user,\n" +
            "    LastMessage.timestamp AS last_message_timestamp,\n" +
            "    LastMessage.content AS last_message_content,\n" +
            "    UnreadCount.unread_messages_count\n" +
            "FROM (\n" +
            "    SELECT\n" +
            "        CASE\n" +
            "            WHEN sender = #{receiver} THEN receiver\n" +
            "            ELSE sender\n" +
            "        END AS contact_user,\n" +
            "        MAX(id) AS last_message_id\n" +
            "    FROM message_table\n" +
            "    WHERE #{receiver} IN (sender, receiver)\n" +
            "    GROUP BY contact_user\n" +
            ") AS ContactUser\n" +
            "JOIN message_table AS LastMessage ON LastMessage.id = ContactUser.last_message_id\n" +
            "LEFT JOIN (\n" +
            "    SELECT \n" +
            "        receiver,\n" +
            "        sender,\n" +
            "        COUNT(*) AS unread_messages_count\n" +
            "    FROM message_table\n" +
            "    WHERE receiver = #{receiver} AND state = 0\n" +
            "    GROUP BY sender\n" +
            ") AS UnreadCount ON UnreadCount.sender = ContactUser.contact_user\n" +
            "ORDER BY LastMessage.timestamp DESC;\n")
    List<MessageDTO> getUserMessages(@Param("receiver") String receiver);
}