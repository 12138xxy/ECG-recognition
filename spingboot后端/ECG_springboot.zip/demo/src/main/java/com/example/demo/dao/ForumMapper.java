package com.example.demo.dao;

import com.example.demo.model.Comment;
import com.example.demo.model.Doctor;
import com.example.demo.model.Like;
import com.example.demo.model.UserForum;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ForumMapper {

    @Insert("INSERT INTO user_forum (username, nickname, title, content, time, likecount, commentcount) VALUES (#{username}, #{nickname}, #{title}, #{content}, #{time}, #{likecount}, #{commentcount})")
    void insert(UserForum userForum);

    @Select("SELECT COUNT(*) FROM user_forum WHERE username = #{username}")
    int countByAccount(String username);

    @Select("SELECT nickname from user_forum WHERE username = #{username}")
    String GetNickname(String username);

    @Select("SELECT * from user_forum order by id DESC")
    List<UserForum> getContent();

    @Update("update user_forum set likecount = likecount + 1 where id = #{id}")
    void updateLike(int id);

    @Insert("INSERT INTO like_forum (forum_id, username) VALUES (#{postId}, #{username})")
    void insertLike1(Like like);

    @Update("update user_forum set likecount = likecount - 1 where id = #{id}")
    void updateLike2(int id);

    @Insert("DELETE FROM like_forum WHERE forum_id = #{postId} AND username = #{username}")
    void insertLike2(Like like);

    @Select("SELECT * FROM user_forum where id = #{id}")
    UserForum selectForumById(int id);

    @Select("SELECT COUNT(*) FROM like_forum WHERE forum_id = #{postId} AND username = #{username}")
    int checkLikeStatus(@Param("postId") int postId, @Param("username") String username);

    @Select("SELECT * FROM forum_comment WHERE id_forum = #{postId}")
    List<Comment> findAllByPostId(@Param("postId") int postId);

    @Insert("INSERT INTO forum_comment (id_forum, username, nickname, content, time) VALUES (#{id_forum}, #{username}, #{nickname}, #{content}, #{timestamp})")
    void addComment(Comment comment);

    @Update("update user_forum set commentcount = commentcount + 1 where id = #{id}")
    void updateComment(int id);

    @Select("SELECT * FROM user_forum WHERE content LIKE CONCAT('%', #{content}, '%')")
    List<UserForum> searchByContent(@Param("content") String content);

}
