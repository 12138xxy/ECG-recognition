package com.example.demo.dao;

import com.example.demo.model.UserInfo;
import org.apache.ibatis.annotations.*;

@Mapper
public interface UserInfoMapper {
    // 检索个人信息
    @Select("SELECT username, height, weight, birthday FROM personal_data WHERE username = #{username}")
    UserInfo selectByUsername(@Param("username") String username);

    // 插入个人信息
    @Insert("INSERT INTO personal_data(username, height, weight, birthday) VALUES(#{username}, #{height}, #{weight}, #{birthday})")
    void insertUserInfo(UserInfo userInfo);

    // 更新个人信息
    @Update("UPDATE personal_data SET height = #{height}, weight = #{weight}, birthday = #{birthday} WHERE username = #{username}")
    void updateUserInfo(UserInfo userInfo);
}
