package com.example.demo.Controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
public class FileUploadController {

    @PostMapping("/upload")
    public String handleFileUpload(@RequestParam("file") MultipartFile file) {
        String fileName = file.getOriginalFilename();
        try {
            // 输出文件内容，仅适用于文本文件
            String content = new String(file.getBytes());
            System.out.println("File content: " + content);
        } catch (IOException e) {
            e.printStackTrace();
            return "Failed to read file content";
        }

        // 返回文件名
        return "Received file: " + fileName;
    }
}