package com.example.demo.dao;

import com.example.demo.model.Doctor;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface DoctorMapper {
    @Select("SELECT * FROM doctor_table WHERE username = #{username}")
    Doctor selectByUsername(@Param("username") String username);

    @Insert("INSERT INTO doctor_table(username, name, id, hospital, title, department, year) VALUES(#{username}, #{name}, #{id}, #{hospital}, #{title}, #{department}, #{year})")
    void insertDoctor(Doctor doctor);

    @Update("UPDATE doctor_table SET name = #{name}, id = #{id}, hospital = #{hospital}, title = #{title}, department = #{department}, year = #{year} WHERE username = #{username}")
    void updateDoctor(Doctor doctor);

    @Select("SELECT * FROM doctor_table")
    List<Doctor> findAll();

    @Select("SELECT * FROM doctor_table WHERE name LIKE CONCAT('%', #{name}, '%')")
    List<Doctor> searchByName(@Param("name") String name);

    @Update("UPDATE user_table SET identity = '医生' WHERE username = #{username}")
    void updateUserIdentity(@Param("username") String username);

    @Select("SELECT identity FROM user_table WHERE username = #{username}")
    String findIdentityByUsername(@Param("username") String username);
}
