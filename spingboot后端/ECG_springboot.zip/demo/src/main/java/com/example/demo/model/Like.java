package com.example.demo.model;

public class Like {
    private int postId; // 帖子ID
    private String username; // 用户名

    // 构造函数
    public Like() {
    }

    // Getter和Setter
    public int getPostId() {
        return postId;
    }

    public void setPostId(int postId) {
        this.postId = postId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
