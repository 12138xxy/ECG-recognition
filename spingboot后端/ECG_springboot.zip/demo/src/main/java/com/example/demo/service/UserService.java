package com.example.demo.service;

import com.example.demo.dao.UserMapper;
import com.example.demo.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserMapper userMapper;

    @Autowired
    public UserService(UserMapper userMapper){this.userMapper = userMapper;}

    public boolean validateUser(String username, String password) {
        User user = userMapper.findUserByUsername(username);
        userMapper.updateStatus(username);
        return user != null && user.getPassword().equals(password);
    }

    public boolean register(User newUser) {
        // 检查账号是否已存在
        int count = userMapper.countByAccount(newUser.getUsername());
        if (count > 0) {
            // 账号已存在
            return false;
        }
        // 账号不存在，继续注册流程
        userMapper.insert(newUser);
        userMapper.insert_status(newUser.getUsername());
        return true;
    }

    public String GetNickname(String username){
        return userMapper.GetNickname(username);
    }

    public List<String> getContacts(String username) {
        return userMapper.findContactsByUsername(username);
    }
}
