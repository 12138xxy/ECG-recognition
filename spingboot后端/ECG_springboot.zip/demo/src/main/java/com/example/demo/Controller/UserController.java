package com.example.demo.Controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

@RestController
public class UserController {

    private final UserService userService;

    private final String directoryPath = "/com.example.demo/userimage";


    @Autowired
    public UserController(UserService userService){this.userService = userService;}

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginUser) {
        boolean isValidUser = userService.validateUser(loginUser.getUsername(), loginUser.getPassword());
        if (isValidUser) {
            return ResponseEntity.ok("登录成功");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("账号或密码错误");
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        boolean isRegistered = userService.register(user);
        if (isRegistered) {
            return ResponseEntity.ok("注册成功");
        } else {
            return ResponseEntity.badRequest().body("该用户已存在");
        }
    }

    @GetMapping("/getNickname")
    public String getNickname(@RequestParam String username) {
        return userService.GetNickname(username);
    }

    @GetMapping("/contacts/{username}")
    public List<String> getContacts(@PathVariable String username) {
        return userService.getContacts(username);
    }

    @PostMapping("/setAvatar")
    public ResponseEntity<?> setAvatar(@RequestParam("username") String username, @RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("File is empty");
        }

        try {
            String filename = username + ".jpg"; // 假设所有头像都转换为jpg格式
            Path filePath = Paths.get(directoryPath, filename);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Could not save file");
        }

        return ResponseEntity.ok("Avatar updated successfully");
    }

    @GetMapping("/getAvatar/{username}")
    public ResponseEntity<?> getAvatar(@PathVariable String username) {
        String filename = username + ".jpg"; // 与上传时相同的命名规则
        Path filePath = Paths.get(directoryPath, filename);
        System.out.println(filename);

        if (!Files.exists(filePath)) {
            return ResponseEntity.notFound().build();
        }

        try {
            Resource fileResource = (Resource) new UrlResource(filePath.toUri());
            return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .body(fileResource);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Could not read file");
        }
    }


}
