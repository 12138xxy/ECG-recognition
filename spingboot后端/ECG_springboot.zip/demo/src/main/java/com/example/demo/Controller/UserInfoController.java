package com.example.demo.Controller;

import com.example.demo.model.UserInfo;
import com.example.demo.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserInfoController {
    @Autowired
    private UserInfoService userInfoService;

    @GetMapping("/info")
    public UserInfo getUserInfo(@RequestParam String username) {
        return userInfoService.getUserInfo(username);
    }

    @PostMapping("/edit")
    public ResponseEntity<?> editUserInfo(@RequestBody UserInfo userInfo) {
        userInfoService.editUserInfo(userInfo);
        return ResponseEntity.ok().build();
    }
}
