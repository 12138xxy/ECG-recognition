package com.example.demo.Controller;

import com.example.demo.model.Comment;
import com.example.demo.model.Doctor;
import com.example.demo.model.Like;
import com.example.demo.model.UserForum;
import com.example.demo.service.ForumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ForumController {

    private final ForumService forumService;

    @Autowired
    public ForumController(ForumService forumService){this.forumService = forumService;}

    @PostMapping("/forum")
    public ResponseEntity<?> forum(@RequestBody UserForum userForum) {
        forumService.insertForum(userForum);
        boolean haveForum = forumService.showForum(userForum);
        if(haveForum){
            return ResponseEntity.ok("添加成功");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("暂未发表评论");
        }
    }

    @PostMapping("/addForum")
    public ResponseEntity<?> addForum(@RequestBody UserForum userForum) {
        forumService.insertForum(userForum);
        boolean haveForum = forumService.showForum(userForum);
        if(haveForum){
            return ResponseEntity.ok("添加成功");
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("暂未发表评论");
        }
    }


    @RequestMapping("/getContent")
    public List<UserForum> getData() {
        return forumService.getData();
    }

    @GetMapping("/forum/{id}")
    public UserForum getForumById(@PathVariable("id") int id) {
        return forumService.getForumById(id);
    }

    @PostMapping("/like")
    public void likePost(@RequestBody Like likeRequest) {
        forumService.updateLike(likeRequest);
    }

    @GetMapping("/forum/like-status")
    public boolean getLikeStatus(@RequestParam("postId") int postId, @RequestParam("username") String username) {
        return forumService.isPostLikedByUser(postId, username);
    }

    @GetMapping("/comments/{postId}")
    public List<Comment> getCommentsByPostId(@PathVariable("postId") int postId) {
        return forumService.getCommentsByPostId(postId);
    }

    @PostMapping("/comments/add")
    public String addComment(@RequestBody Comment comment) {
        forumService.addComment(comment);
        System.out.println(comment.getForum_id());
        return "Comment added successfully";
    }

    @GetMapping("/forum/search")
    public List<UserForum> searchByContent(@RequestParam String content) {
        return forumService.searchByContent(content);
    }
}
