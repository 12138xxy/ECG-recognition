package com.example.demo.dao;

import com.example.demo.model.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("SELECT * FROM user_table WHERE username = #{username}")
    User findUserByUsername(String username);

    @Update("UPDATE user_status SET status = 1 WHERE username = #{username}")
    void updateStatus(String username);

    @Update("UPDATE user_status SET status = 0 WHERE username = #{username}")
    void updateStatus0(String username);

    @Insert("INSERT INTO user_table (nickname, username, password, phone, identity) VALUES (#{nickname}, #{username}, #{password}, #{phone}, #{identity})")
    void insert(User user);

    @Insert("INSERT INTO user_status (username, status) VALUES (#{username}, 0)")
    void insert_status(String username);

    @Select("SELECT COUNT(*) FROM user_table WHERE username = #{username}")
    int countByAccount(String username);

    @Select("SELECT nickname from user_table WHERE username = #{username}")
    String GetNickname(String username);

    @Select("SELECT user2 FROM contact_table WHERE user1 = #{username} " +
            "UNION " +
            "SELECT user1 FROM contact_table WHERE user2 = #{username}")
    List<String> findContactsByUsername(String username);

}
