package com.example.demo.service;

import com.example.demo.dao.MessageMapper;
import com.example.demo.model.MessageDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;

@Service
public class MessageService {

    private final MessageMapper messageMapper;

    @Autowired
    public MessageService(MessageMapper messageMapper) {
        this.messageMapper = messageMapper;
    }

    public List<MessageDTO> getUserMessages(String receiver) {
        List<MessageDTO> messages = messageMapper.getUserMessages(receiver);
        // 对消息列表按时间戳进行排序
        messages.sort(Comparator.comparing(MessageDTO::getLatestMessageTimestamp).reversed());
        return messages;
    }
}
