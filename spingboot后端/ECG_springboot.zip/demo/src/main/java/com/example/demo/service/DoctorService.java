package com.example.demo.service;

import com.example.demo.dao.DoctorMapper;
import com.example.demo.model.Doctor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorService {
    @Autowired
    private DoctorMapper doctorMapper;

    public Doctor getDoctorInfo(String username) {
        return doctorMapper.selectByUsername(username);
    }

    public void saveDoctorInfo(Doctor doctor) {
        Doctor existingDoctor = doctorMapper.selectByUsername(doctor.getUsername());
        if (existingDoctor == null) {
            doctorMapper.insertDoctor(doctor);
        } else {
            doctorMapper.updateDoctor(doctor);
        }
    }

    public List<Doctor> getAllDoctors() {
        return doctorMapper.findAll();
    }

    public List<Doctor> searchDoctorsByName(String name) {
        return doctorMapper.searchByName(name);
    }

    public void authenticateDoctor(String username) {
        doctorMapper.updateUserIdentity(username);
    }

    public String getUserIdentity(String username) {
        return doctorMapper.findIdentityByUsername(username);
    }
}
