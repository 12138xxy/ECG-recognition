package com.example.demo.model;

public class Comment {
    public int id_forum;
    public String username;
    public String nickname;
    public String content;
    public long timestamp;

    public Comment(int id_forum, String username, String nickname, String content, long timestamp){
        this.id_forum = id_forum;
        this.username = username;
        this.nickname = nickname;
        this.content = content;
        this.timestamp = timestamp;
    }

    public int getForum_id() {
        return id_forum;
    }

    public void setForum_id(int id_forum) {
        this.id_forum = id_forum;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
