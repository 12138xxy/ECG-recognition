package com.example.demo.model;

import java.util.Date;

public class UserInfo {
    private String username;
    private Double height;
    private Double weight;
    private String birthday;

    // Getters and Setters

    public String getUsername() {
        return username;
    }

    public Double getHeight() {
        return height;
    }

    public Double getWeight() {
        return weight;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setHeight(Double height) {
        this.height = height;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
}
