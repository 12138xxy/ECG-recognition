package com.example.demo.Controller;

import com.example.demo.model.Doctor;
import com.example.demo.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/doctor")
public class DoctorController {
    @Autowired
    private DoctorService doctorService;

    @GetMapping("/info")
    public Doctor getDoctorInfo(@RequestParam String username) {
        return doctorService.getDoctorInfo(username);
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveDoctorInfo(@RequestBody Doctor doctor) {
        doctorService.saveDoctorInfo(doctor);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/list")
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }

    @GetMapping("/search")
    public List<Doctor> searchDoctorsByName(@RequestParam String name) {
        return doctorService.searchDoctorsByName(name);
    }

    @PostMapping("/authenticateDoctor")
    public ResponseEntity<?> authenticateDoctor(@RequestBody Doctor doctor) {
        doctorService.authenticateDoctor(doctor.getUsername());
        return ResponseEntity.ok().build();
    }

    @GetMapping("/identity")
    public String getUserIdentity(@RequestParam String username) {
        return doctorService.getUserIdentity(username);
    }


}
