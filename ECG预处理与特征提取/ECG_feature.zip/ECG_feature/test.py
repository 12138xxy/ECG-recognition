import pandas as pd
import requests
import json
import scipy.io as sio

api_url = 'http://47.120.36.167:5656/api/emotion'
# 发送 GET 请求
# sig = sio.loadmat('')['val'][0].astype('float')
# print(sig)
# # sig=sig[0:2000]
# # 设置采样频率
fs = 300
sig = pd.read_csv('E:\WESAD_ECG_SSL\data.csv')

sig = sig.columns
# # 创建包含fs和sig的字典
json_data = {'fs': fs, 'sig': sig.tolist()}

#
# # 将字典转换为JSON格式的字符串
# # json_data = json.dumps(data_dict, indent=2)
#
# # response_post = requests.post(api_url, json=data_to_send, headers={'Content-Type': 'application/json'})
headers = {"Content-Type": "application/json",
           "Connection": "close"}
# #
# #
# #
response_post = requests.post(api_url, json=json_data, headers=headers)
# response_data = response_post1.json()
# response_data = response_data.strip('\"')
# data_list = json.loads(response_data)
# first_dict = data_list[0]
# sig1 = first_dict.get("sig")
# json_data2 = {'fs': fs, 'sig': sig1}
# api_url2 = 'http://47.120.36.167:5050'
# response_post = requests.post(api_url2, json=json_data2, headers=headers)

#
# # print(response.json())
#
# # response_post = requests.post(api_url, json=json_data, headers=headers, verify=False)
# # response_post = requests.get(api_url, headers=headers)
if response_post.status_code == 200:
    try:
        # 尝试解析 JSON 响应
        json_data = response_post.json()
        print('GET Response:', json_data)
    except requests.exceptions.JSONDecodeError:
        print('Error decoding JSON: Empty response or invalid JSON format')
else:
    print(f'Error: {response_post.status_code} - {response_post.text}')

# If it's a binary file with a specific structure, you may need to parse it accordingly
# For example, using struct module for binary data

# import struct
# data = struct.unpack('format_string', file_content)

# Process or print the content as needed
