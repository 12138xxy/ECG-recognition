from __future__ import absolute_import, division, print_function

# 第三方导入
import pywt
import numpy as np
import scipy as sp
from scipy import signal

from utils.tools.higuchi_fractal_dimension import hfd


# 本地导入
# from utils.tools.higuchi_fractal_dimension import hfd


class FullWaveformFeatures:

    """
    生成一个包含一个心电图信号的完整波形统计特征的字典。

    参数
    ----------
    ts : numpy array
        完整波形时间数组。
    signal_raw : numpy array
        原始完整波形。
    signal_filtered : numpy array
        过滤后的完整波形。
    rpeaks : numpy array
        R峰的数组索引。
    templates_ts : numpy array
        模板波形时间数组。
    templates : numpy array
        模板波形。
    fs : int, float
        采样频率（Hz）。

    返回
    -------
    full_waveform_features : 字典
        完整波形特征。
    """

    def __init__(self, ts, signal_raw, signal_filtered, rpeaks, templates_ts, templates, fs):

        # 设置参数
        self.ts = ts
        self.signal_raw = signal_raw
        self.signal_filtered = signal_filtered
        self.rpeaks = rpeaks
        self.templates_ts = templates_ts
        self.templates = templates
        self.fs = fs

        # 特征字典
        self.full_waveform_features = dict()

    def get_full_waveform_features(self):
        return self.full_waveform_features

    def extract_full_waveform_features(self):
        self.full_waveform_features.update(self.calculate_basic_features())
        # self.full_waveform_features.update(self.calculate_stationary_wavelet_transform_features())

    def calculate_basic_features(self):

        # 空字典
        basic_features = dict()

        # 计算统计特征
        basic_features['full_waveform_min'] = np.min(self.signal_filtered)
        basic_features['full_waveform_max'] = np.max(self.signal_filtered)
        basic_features['full_waveform_mean'] = np.mean(self.signal_filtered)
        basic_features['full_waveform_median'] = np.median(self.signal_filtered)
        basic_features['full_waveform_std'] = np.std(self.signal_filtered)
        basic_features['full_waveform_skew'] = sp.stats.skew(self.signal_filtered)
        basic_features['full_waveform_kurtosis'] = sp.stats.kurtosis(self.signal_filtered)

        return basic_features

    def calculate_stationary_wavelet_transform_features(self):

        # 空字典
        stationary_wavelet_transform_features = dict()

        # 分解级别
        decomp_level = 4

        # 静止小波变换
        swt = self.stationary_wavelet_transform(self.signal_filtered, wavelet='db4', level=decomp_level)

        # 设置频率带
        freq_band_low = (3, 10)
        freq_band_med = (10, 30)
        freq_band_high = (30, 45)

        """频率域"""
        for level in range(len(swt)):

            """细节"""
            # 计算韦尔奇周期图
            fxx, pxx = signal.welch(x=swt[level]['d'], fs=self.fs)

            # 获取频率带
            freq_band_low_index = np.logical_and(fxx >= freq_band_low[0], fxx < freq_band_low[1])
            freq_band_med_index = np.logical_and(fxx >= freq_band_med[0], fxx < freq_band_med[1])
            freq_band_high_index = np.logical_and(fxx >= freq_band_high[0], fxx < freq_band_high[1])

            # 计算最大功率
            max_power_low = np.max(pxx[freq_band_low_index])
            max_power_med = np.max(pxx[freq_band_med_index])
            max_power_high = np.max(pxx[freq_band_high_index])

            # 计算平均功率
            mean_power_low = np.trapz(y=pxx[freq_band_low_index], x=fxx[freq_band_low_index])
            mean_power_med = np.trapz(y=pxx[freq_band_med_index], x=fxx[freq_band_med_index])
            mean_power_high = np.trapz(y=pxx[freq_band_high_index], x=fxx[freq_band_high_index])

            # 计算最大/平均功率比
            stationary_wavelet_transform_features['swt_d_' + str(level+1) + '_low_power_ratio'] = \
                max_power_low / mean_power_low
            stationary_wavelet_transform_features['swt_d_' + str(level+1) + '_med_power_ratio'] = \
                max_power_med / mean_power_med
            stationary_wavelet_transform_features['swt_d_' + str(level+1) + '_high_power_ratio'] = \
                max_power_high / mean_power_high

            """近似"""
            # 计算韦尔奇周期图
            fxx, pxx = signal.welch(x=swt[level]['a'], fs=self.fs)

            # 获取频率带
            freq_band_low_index = np.logical_and(fxx >= freq_band_low[0], fxx < freq_band_low[1])
            freq_band_med_index = np.logical_and(fxx >= freq_band_med[0], fxx < freq_band_med[1])
            freq_band_high_index = np.logical_and(fxx >= freq_band_high[0], fxx < freq_band_high[1])

            # 计算最大功率
            max_power_low = np.max(pxx[freq_band_low_index])
            max_power_med = np.max(pxx[freq_band_med_index])
            max_power_high = np.max(pxx[freq_band_high_index])

            # 计算平均功率
            mean_power_low = np.trapz(y=pxx[freq_band_low_index], x=fxx[freq_band_low_index])
            mean_power_med = np.trapz(y=pxx[freq_band_med_index], x=fxx[freq_band_med_index])
            mean_power_high = np.trapz(y=pxx[freq_band_high_index], x=fxx[freq_band_high_index])

            # 计算最大/平均功率比
            stationary_wavelet_transform_features['swt_a_' + str(level+1) + '_low_power_ratio'] = \
                max_power_low / mean_power_low
            stationary_wavelet_transform_features['swt_a_' + str(level+1) + '_med_power_ratio'] = \
                max_power_med / mean_power_med
            stationary_wavelet_transform_features['swt_a_' + str(level+1) + '_high_power_ratio'] = \
                max_power_high / mean_power_high

        """非线性"""
        for level in range(len(swt)):

            """细节"""
            # 对数能量熵
            stationary_wavelet_transform_features['swt_d_' + str(level+1) + '_energy_entropy'] = \
                np.sum(np.log10(np.power(swt[level]['d'], 2)))

            # Higuchi分形
            stationary_wavelet_transform_features['swt_d_' + str(level+1) + '_higuchi_fractal'] = \
                hfd(swt[level]['d'], k_max=10)

            """近似"""
            # 对数能量熵
            stationary_wavelet_transform_features['swt_a_' + str(level+1) + '_energy_entropy'] = \
                np.sum(np.log10(np.power(swt[level]['a'], 2)))

            # Higuchi分形
            stationary_wavelet_transform_features['swt_a_' + str(level+1) + '_higuchi_fractal'] = \
                hfd(swt[level]['a'], k_max=10)

        return stationary_wavelet_transform_features

    @staticmethod
    def calculate_decomposition_level(waveform_length, level):

        # 设置起始乘法因子
        factor = 0

        # 设置更新后的波形长度变量
        waveform_length_updated = None

        # 如果波形长度不适合提议的分解级别
        if waveform_length % 2**level != 0:

            # 计算余数
            remainder = waveform_length % 2**level

            # 在找到最小因子之前循环乘法因子
            while remainder != 0:

                # 更新乘法因子
                factor += 1

                # 更新波形长度
                waveform_length_updated = factor * waveform_length

                # 计算更新后的余数
                remainder = waveform_length_updated % 2**level

            return waveform_length_updated

        # 如果波形适合提议的分解级别
        else:
            return waveform_length

    @staticmethod
    def add_padding(waveform, waveform_length_updated):

        # 计算所需填充
        pad_count = np.abs(len(waveform) - waveform_length_updated)

        # 计算波形之前的填充
        pad_before = int(np.floor(pad_count / 2.0))

        # 计算波形之后的填充
        pad_after = pad_count - pad_before

        # 将填充添加到波形
        waveform_padded = np.append(np.zeros(pad_before), np.append(waveform, np.zeros(pad_after)))

        return waveform_padded, pad_before, pad_after

    def stationary_wavelet_transform(self, waveform, wavelet, level):

        # 计算波形长度
        waveform_length = len(waveform)

        # 计算某个分解级别的SWT的最小波形长度
        waveform_length_updated = self.calculate_decomposition_level(waveform_length, level)

        # 对波形进行必要的填充
        waveform_padded, pad_before, pad_after = self.add_padding(waveform, waveform_length_updated)

        # 计算静止小波变换
        swt = pywt.swtn(waveform_padded, wavelet=wavelet, level=level, start_level=0)

        # 循环遍历分解级别并移除填充
        for lev in range(len(swt)):

            # 近似
            swt[lev]['a'] = swt[lev]['a'][pad_before:len(waveform_padded) - pad_after]

            # 细节
            swt[lev]['d'] = swt[lev]['d'][pad_before:len(waveform_padded) - pad_after]

        return swt
