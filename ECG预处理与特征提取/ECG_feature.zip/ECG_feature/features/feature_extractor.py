from __future__ import absolute_import, division, print_function

import numpy as np
import pandas as pd
from biosppy.signals import ecg
from biosppy.signals.tools import filter_signal
from scipy.stats import kurtosis
from vmdpy import VMD

from features.medical_features import *

from features.full_waveform_features import *

# from features.full_waveform_features import FullWaveformFeatures
# from features.medical_features import MedicalECGFeatures


class Features:

    def __init__(self, fs, feature_groups, sig):
        self.fs = fs
        self.feature_groups = feature_groups
        self.sig = sig

        self.features = pd.DataFrame()

    def get_features(self):
        return self.features

    def extract_features(self, filter_bandwidth, n_signals=None, show=False,
                         normalize=True, polarity_check=True, template_before=0.2, template_after=0.4):
        signal_raw = self.sig
        ts, signal_raw, signal_filtered, rpeaks, templates_ts, templates = self._preprocess_signal(
            signal_raw=signal_raw, filter_bandwidth=filter_bandwidth, normalize=normalize,
            polarity_check=polarity_check, template_before=template_before, template_after=template_after
        )

        # 获取全特征
        features = self._group_features(ts=ts, signal_raw=signal_raw,
                                        signal_filtered=signal_filtered, rpeaks=rpeaks,
                                        templates_ts=templates_ts, templates=templates,
                                        template_before=template_before, template_after=template_after)

        # 加入到特征FataFrame
        self.features = self.features._append(features, ignore_index=True)

    def _preprocess_signal(self, signal_raw, filter_bandwidth, normalize, polarity_check,
                           template_before, template_after):

        # 变分模态分解+FIR滤波
        signal_filtered = self._apply_filter(signal_raw, filter_bandwidth)

        # 处理ecg获取基本信息
        ecg_object = ecg.ecg(signal=signal_filtered, sampling_rate=self.fs, show=False)

        ts = ecg_object['ts']  # Signal time array

        rpeaks = ecg_object['rpeaks']  # rpeak indices

        # 获取模板ecg信号
        templates, rpeaks = self._extract_templates(signal_filtered, rpeaks, template_before, template_after)
        templates_ts = np.linspace(-template_before, template_after, templates.shape[1], endpoint=False)

        # 极性检查
        signal_raw, signal_filtered, templates = self._check_waveform_polarity(polarity_check=polarity_check,
                                                                               signal_raw=signal_raw,
                                                                               signal_filtered=signal_filtered,
                                                                               templates=templates)
        # 信号尺度规范化
        signal_raw, signal_filtered, templates = self._normalize_waveform_amplitude(normalize=normalize,
                                                                                    signal_raw=signal_raw,
                                                                                    signal_filtered=signal_filtered,
                                                                                    templates=templates)

        return ts, signal_raw, signal_filtered, rpeaks, templates_ts, templates

    @staticmethod
    def _check_waveform_polarity(polarity_check, signal_raw, signal_filtered, templates):

        if polarity_check:

            # 获取绝对最大值和绝对最小值
            templates_min = np.min(np.median(templates, axis=1))
            templates_max = np.max(np.median(templates, axis=1))

            if np.abs(templates_min) > np.abs(templates_max):
                return signal_raw * -1, signal_filtered * -1, templates * -1
            else:
                return signal_raw, signal_filtered, templates

    @staticmethod
    def _normalize_waveform_amplitude(normalize, signal_raw, signal_filtered, templates):
        if normalize:
            templates_std = np.std(np.median(templates, axis=1))
            templates_mean = np.mean(np.median(templates, axis=1))

            return (signal_raw - templates_mean) / templates_std, (signal_filtered - templates_mean) / templates_std, (
                        templates - templates_mean) / templates_std

    def _extract_templates(self, signal_filtered, rpeaks, before, after):

        # 将时间边界转换为采样点数
        before = int(before * self.fs)
        after = int(after * self.fs)

        # 对R峰位置索引进行升序排序
        rpeaks = np.sort(rpeaks)

        # 获取波形中的采样点数
        length = len(signal_filtered)

        # 创建空列表用于存储模板
        templates = []

        # 创建空列表用于存储与模板维度匹配的新R峰位置索引
        rpeaks_new = np.empty(0, dtype=int)

        # 遍历R峰位置索引
        for rpeak in rpeaks:

            # R峰之前
            a = rpeak - before
            if a < 0:
                continue

            # R峰之后
            b = rpeak + after
            if b > length:
                break

            # 将模板添加到列表
            templates.append(signal_filtered[a:b])

            # 将新的R峰位置索引添加到列表
            rpeaks_new = np.append(rpeaks_new, rpeak)

        # 将列表转换为numpy数组
        templates = np.array(templates).T

        return templates, rpeaks_new

    def _apply_filter(self, signal_raw, filter_bandwidth):
        """应用FIR带通滤波器到波形。"""
        # VMD分解
        modes, _, _ = VMD(f=signal_raw, alpha=2000, tau=0.1, K=5, DC=1, init='nndsvd', tol=1e-7)
        # 对每个模态检查峭度，并决定是否去噪
        denoised_modes = []
        for mode in modes:
            mode_kurtosis = kurtosis(mode)
            if mode_kurtosis > 3.5:
                # 如果峭度超过阈值，则对模态应用去噪
                denoised_mode, _, _ = filter_signal(signal=mode, ftype='FIR', band='bandpass',
                                                    order=int(0.3 * self.fs), frequency=filter_bandwidth,
                                                    sampling_rate=self.fs)
                denoised_modes.append(denoised_mode)
            else:
                denoised_modes.append(mode)

        # 将去噪的模态组合成一个处理过的信号
        signal_filtered = np.sum(denoised_modes, axis=0)

        # signal_filtered, _, _ = filter_signal(signal=signal_raw, ftype='FIR', band='bandpass',
        #                                       order=int(0.3 * self.fs), frequency=filter_bandwidth,
        #                                       sampling_rate=self.fs)
        return signal_filtered

    def _group_features(self, ts, signal_raw, signal_filtered, rpeaks,
                        templates_ts, templates, template_before, template_after):
        """获取包含所有心电图(ECG)特征的字典。"""

        # 空特征字典
        features = dict()

        # 遍历特征组
        for feature_group in self.feature_groups:

            # 全波形特征
            if feature_group == 'full_waveform_features':
                # 提取特征
                full_waveform_features = FullWaveformFeatures(ts=ts, signal_raw=signal_raw,
                                                              signal_filtered=signal_filtered, rpeaks=rpeaks,
                                                              templates_ts=templates_ts, templates=templates,
                                                              fs=self.fs)
                full_waveform_features.extract_full_waveform_features()
                medical_features = MedicalECGFeatures(ts=ts, signal_raw=signal_raw,
                                                      signal_filtered=signal_filtered, rpeaks=rpeaks,
                                                      templates_ts=templates_ts, templates=templates,
                                                      fs=self.fs)
                medical_features.extract_medical_features()
                # 更新特征字典
                # features['sig'] = signal_filtered
                features.update(full_waveform_features.get_full_waveform_features())
                features.update(medical_features.get_medical_features())

        return pd.Series(data=features)
