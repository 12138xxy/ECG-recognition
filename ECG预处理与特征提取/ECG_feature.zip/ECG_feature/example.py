import os
import sys
import numpy as np
import pandas as pd
import matplotlib.pylab as plt


sys.path.insert(0, os.path.dirname(os.getcwd()))
from features.feature_extractor import Features
from flask import Flask, request, jsonify
import scipy.io as sio
import json

app = Flask(__name__)


@app.route('/api/example', methods=['POST'])
def example_post_api():
    data = request.get_json()
    fs = data['fs']
    sig = data['sig']

    ecg_features = Features(fs=fs, sig=sig, feature_groups=['full_waveform_features'])
    ecg_features.extract_features(
        filter_bandwidth=[3, 45], n_signals=None, show=True, normalize=True, polarity_check=True,
        template_before=0.25, template_after=0.4
    )
    features = ecg_features.get_features()
    features_json = features.to_json(orient='records')
    return jsonify(features_json)




#
if __name__ == '__main__':
    app.run(debug=True)

