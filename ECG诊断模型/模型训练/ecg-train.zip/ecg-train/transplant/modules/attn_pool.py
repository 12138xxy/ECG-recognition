import tensorflow as tf


class AttentionPooling(tf.keras.layers.Layer):
    def __init__(self, transformer, keepdims=False, **kwargs):
        super().__init__(**kwargs)
        self.transformer = transformer
        self.keepdims = keepdims
        initial_pool_token_embedding = tf.random.truncated_normal((transformer.d_model,))
        self.pool_token_embedding = tf.Variable(initial_pool_token_embedding, trainable=True)

    def call(self, x, training=None, mask=None):
        batch_size = tf.shape(x)[0]  # 动态形状

        pool_token_embedding = tf.tile(self.pool_token_embedding, (batch_size,))
        pool_token_embedding = tf.reshape(pool_token_embedding, (batch_size, 1, self.transformer.d_model))
        x = tf.concat([pool_token_embedding, x], axis=1)  # x.shape = (batch_size, seq_len + 1, d_model)
        if mask is not None:
            pool_token_embedding_mask = tf.zeros((batch_size, 1))
            mask = tf.concat([pool_token_embedding_mask, mask], axis=1)  # mask.shape = (batch_size, seq_len + 1)

        x = self.transformer(x, training=training, mask=mask)
        if self.keepdims:
            x = x[:, :1, :]
        else:
            x = x[:, 0, :]
        return x
