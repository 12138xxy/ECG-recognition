import os

import numpy as np

from transplant.utils import load_pkl

ds_segment_size = 2 ** 20 + 1   # 1,048,577
ds_frame_size = 2 ** 11 + 1   # 2,049
ds_patient_ids = np.arange(11000)
ds_sampling_rate = 250
ds_mean = 0.0018  # 整个数据集的均值
ds_std = 1.3711   # 整个数据集的标准差

ds_beat_names = {
    0: 'undefined',
    1: 'normal',
    2: 'pac',
    3: 'aberrated',
    4: 'pvc'
}

ds_rhythm_names = {
    0: 'undefined',
    1: 'end',
    2: 'noise',
    3: 'normal',
    4: 'afib',
    5: 'aflut'
}

_HI_PRIO_RHYTHMS = [0, 4, 5]  # undefined / afib / aflut
_LO_PRIO_RHYTHMS = [1, 2, 3]  # end / noise / normal

_HI_PRIO_BEATS = [2, 3, 4]  # pac / aberrated / pvc
_LO_PRIO_BEATS = [0, 1]  # undefined / normal

_HR_TACHYCARDIA = 0
_HR_BRADYCARDIA = 1
_HR_NORMAL = 2
_HR_NOISE = 3

ds_hr_names = {
    _HR_TACHYCARDIA: 'tachy',
    _HR_BRADYCARDIA: 'brady',
    _HR_NORMAL: 'normal',
    _HR_NOISE: 'noise'
}


def rhythm_data_generator(patient_generator, frame_size=2048, samples_per_patient=1):
    for _, (signal, labels) in patient_generator:
        num_segments, segment_size = signal.shape
        patient_rhythm_labels = labels['rtype']  # .npz文件中的变量仅在访问时加载
        for _ in range(samples_per_patient):
            segment_index = np.random.randint(num_segments)
            frame_start = np.random.randint(segment_size - frame_size)
            frame_end = frame_start + frame_size
            x = signal[segment_index, frame_start:frame_end]
            x = np.expand_dims(x, axis=1)

            rhythm_ends, rhythm_labels = patient_rhythm_labels[segment_index]
            frame_rhythm_durations, frame_rhythm_labels = get_rhythm_durations(
                rhythm_ends, rhythm_labels, frame_start, frame_end)
            y = get_rhythm_label(frame_rhythm_durations, frame_rhythm_labels)
            yield x, y


def beat_data_generator(patient_generator, frame_size=2048, samples_per_patient=1):
    for _, (signal, labels) in patient_generator:
        num_segments, segment_size = signal.shape
        patient_beat_labels = labels['btype']
        for _ in range(samples_per_patient):

            segment_index = np.random.randint(num_segments)
            frame_start = np.random.randint(segment_size - frame_size)
            frame_end = frame_start + frame_size
            x = signal[segment_index, frame_start:frame_end]
            x = np.expand_dims(x, axis=1)

            beat_ends, beat_labels = patient_beat_labels[segment_index]
            _, frame_beat_labels = get_complete_beats(
                beat_ends, beat_labels, frame_start, frame_end)
            y = get_beat_label(frame_beat_labels)
            yield x, y


def heart_rate_data_generator(patient_generator, frame_size=2048, label_frame_size=None,
                              samples_per_patient=1):
    if label_frame_size is None:
        label_frame_size = frame_size
    max_frame_size = max(frame_size, label_frame_size)
    for _, (signal, labels) in patient_generator:
        num_segments, segment_size = signal.shape
        patient_beat_labels = labels['btype']
        for _ in range(samples_per_patient):
            segment_index = np.random.randint(num_segments)
            frame_center = np.random.randint(segment_size - max_frame_size) + max_frame_size // 2
            signal_frame_start = frame_center - frame_size // 2
            signal_frame_end = frame_center + frame_size // 2
            x = signal[segment_index, signal_frame_start:signal_frame_end]
            x = np.expand_dims(x, axis=1)

            label_frame_start = frame_center - label_frame_size // 2
            label_frame_end = frame_center + label_frame_size // 2
            beat_ends, _ = patient_beat_labels[segment_index]
            frame_beat_ends = get_complete_beats(beat_ends, start=label_frame_start, end=label_frame_end)
            y = get_heart_rate_label(frame_beat_ends, ds_sampling_rate)
            yield x, y


def signal_generator(patient_generator, frame_size=2048, samples_per_patient=1):
    for _, (signal, _) in patient_generator:
        num_segments, segment_size = signal.shape
        for _ in range(samples_per_patient):

            segment_index = np.random.randint(num_segments)
            frame_start = np.random.randint(segment_size - frame_size)
            frame_end = frame_start + frame_size
            x = signal[segment_index, frame_start:frame_end]
            x = np.expand_dims(x, axis=1)
            yield x


def cpc_data_generator(buffered_patient_generator, context_size, ns, frame_size=2048, context_overlap=0,
                       positive_offset=0, ns_same_segment_prob=None, samples_per_patient=1):
    context_size = context_size * (frame_size - context_overlap)
    for patients_buffer in buffered_patient_generator:
        for _ in range(samples_per_patient):
            patient_index, segment_index = _choose_random_segment(patients_buffer)
            _, (signal, _) = patients_buffer[patient_index]
            segment_size = signal.shape[1]
            context_start = np.random.randint(segment_size - (context_size + frame_size * (positive_offset + 1)))
            context_end = context_start + context_size
            context = []
            for context_frame_start in range(context_start, context_end, frame_size - context_overlap):
                context_frame_end = context_frame_start + frame_size
                context_frame = signal[segment_index, context_frame_start:context_frame_end]
                context_frame = np.expand_dims(context_frame, axis=1)
                context.append(context_frame)
            context = np.array(context)

            positive_sample_start = context_start + context_size + frame_size * positive_offset
            positive_sample_end = positive_sample_start + frame_size
            positive_sample = signal[segment_index, positive_sample_start:positive_sample_end]
            positive_sample = np.expand_dims(positive_sample, axis=1)

            samples = []
            p = (patient_index, segment_index, ns_same_segment_prob) if ns_same_segment_prob else None
            ns_indices = _choose_random_segment(patients_buffer, size=ns, segment_p=p)
            for ns_patient_index, ns_segment_index in ns_indices:
                _, (ns_signal, _) = patients_buffer[ns_patient_index]
                ns_segment_size = ns_signal.shape[1]
                negative_sample_start = np.random.randint(ns_segment_size - frame_size)
                negative_sample_end = negative_sample_start + frame_size
                negative_sample = ns_signal[ns_segment_index, negative_sample_start:negative_sample_end]
                negative_sample = np.expand_dims(negative_sample, axis=1)
                samples.append(negative_sample)

            y = np.random.randint(ns + 1)
            samples.insert(y, positive_sample)
            samples = np.array(samples)
            x = {'context': context,
                 'samples': samples}
            yield x, y


def uniform_patient_generator(db_dir, patient_ids, repeat=True, shuffle=True, include_labels=True,
                              unzipped=False):
    if shuffle:
        patient_ids = np.copy(patient_ids)
    while True:
        if shuffle:
            np.random.shuffle(patient_ids)
        for patient_id in patient_ids:
            patient_data = load_patient_data(db_dir, patient_id, include_labels=include_labels, unzipped=unzipped)
            yield patient_id, patient_data
        if not repeat:
            break


def random_patient_generator(db_dir, patient_ids, patient_weights=None, include_labels=True,
                             unzipped=False):
    while True:
        for patient_id in np.random.choice(patient_ids, size=1024, p=patient_weights):
            patient_data = load_patient_data(db_dir, patient_id, include_labels=include_labels, unzipped=unzipped)
            yield patient_id, patient_data


def count_labels(labels, num_classes):
    return np.array([
        np.bincount(segment_labels, minlength=num_classes) for _, segment_labels in labels
    ])


def calculate_durations(labels, num_classes):
    num_segments = len(labels)
    durations = np.zeros((num_segments, num_classes), dtype='int32')
    for segment_index, (segment_indices, segment_labels) in enumerate(labels):
        segment_durations = np.diff(segment_indices, prepend=0)
        for label in range(num_classes):
            durations[segment_index, label] = segment_durations[segment_labels == label].sum()
    return durations


def unzip_patient_data(db_dir, patient_id, out_dir=None):
    signal, labels = load_patient_data(db_dir, patient_id)
    out_signal_file = os.path.join(out_dir or os.path.curdir, '{:05d}_batched.npy'.format(patient_id))
    out_labels_file = os.path.join(out_dir or os.path.curdir, '{:05d}_batched_lbls.npz'.format(patient_id))
    np.save(out_signal_file, signal)
    np.savez(out_labels_file, **labels)


def load_patient_data(db_dir, patient_id, include_labels=True, unzipped=False):
    signal = load_signal(db_dir, patient_id, unzipped=unzipped)
    if include_labels:
        labels = load_labels(db_dir, patient_id, unzipped=unzipped)
        return signal, labels
    else:
        return signal, None


def load_signal(db_dir, patient_id, unzipped=False, mmap_mode=None):
    if unzipped:
        signal = np.load(os.path.join(db_dir, '{:05d}_batched.npy'.format(patient_id)), mmap_mode=mmap_mode)
    else:
        signal = load_pkl(os.path.join(db_dir, '{:05d}_batched.pkl.gz'.format(patient_id)))
    return signal


def load_labels(db_dir, patient_id, flatten=True, unzipped=False):
    if unzipped:
        flat_labels = np.load(os.path.join(db_dir, '{:05d}_batched_lbls.npz'.format(patient_id)), allow_pickle=True)
        return flat_labels
    else:
        raw_labels = load_pkl(os.path.join(db_dir, '{:05d}_batched_lbls.pkl.gz'.format(patient_id)))
        if flatten:
            flat_labels = flatten_raw_labels(raw_labels)
            return flat_labels
        else:
            return raw_labels


def flatten_raw_labels(raw_labels):
    num_segments = len(raw_labels)
    labels = {'btype': [], 'rtype': [], 'size': num_segments}
    for label_type in ['btype', 'rtype']:
        for segment_labels in raw_labels:
            flat_indices = []
            flat_labels = []
            for label, indices in enumerate(segment_labels[label_type]):
                flat_indices.append(indices)
                flat_labels.append(np.repeat(label, len(indices)))
            flat_indices = np.concatenate(flat_indices)
            flat_labels = np.concatenate(flat_labels)
            sort_index = np.argsort(flat_indices)
            flat_indices = flat_indices[sort_index]
            flat_labels = flat_labels[sort_index]
            labels[label_type].append((flat_indices, flat_labels))
    return labels


def get_rhythm_durations(indices, labels=None, start=0, end=None):
    if end is None:
        end = indices[-1]
    if start >= end:
        raise ValueError('`end` must be greater than `start`')

    start_index = np.searchsorted(indices, start, side='right')
    end_index = np.searchsorted(indices, end, side='left') + 1
    frame_indices = indices[start_index:end_index]

    frame_rhythm_durations = np.diff(frame_indices[:-1], prepend=start, append=end)
    if labels is None:
        return frame_rhythm_durations
    else:
        frame_labels = labels[start_index:end_index]
        return frame_rhythm_durations, frame_labels


def get_complete_beats(indices, labels=None, start=0, end=None):
    if end is None:
        end = indices[-1]
    if start >= end:
        raise ValueError('`end` must be greater than `start`')
    start_index = np.searchsorted(indices, start, side='left') + 1
    end_index = np.searchsorted(indices, end, side='right')
    indices_slice = indices[start_index:end_index]
    if labels is None:
        return indices_slice
    else:
        label_slice = labels[start_index:end_index]
        return indices_slice, label_slice


def get_rhythm_label(durations, labels):
    summed_durations = np.zeros(len(ds_rhythm_names))
    for label in ds_rhythm_names:
        summed_durations[label] = durations[labels == label].sum()
    longest_hp_rhythm = np.argmax(summed_durations[_HI_PRIO_RHYTHMS])
    if summed_durations[_HI_PRIO_RHYTHMS][longest_hp_rhythm] > 0:
        y = _HI_PRIO_RHYTHMS[longest_hp_rhythm]
    else:
        longest_lp_rhythm = np.argmax(summed_durations[_LO_PRIO_RHYTHMS])
        if summed_durations[_LO_PRIO_RHYTHMS][longest_lp_rhythm] > 0:
            y = _LO_PRIO_RHYTHMS[longest_lp_rhythm]
        else:
            y = 0
    return y


def get_beat_label(labels):
    beat_counts = np.bincount(labels, minlength=len(ds_beat_names))
    most_hp_beats = np.argmax(beat_counts[_HI_PRIO_BEATS])
    if beat_counts[_HI_PRIO_BEATS][most_hp_beats] > 0:
        y = _HI_PRIO_BEATS[most_hp_beats]
    else:
        most_lp_beats = np.argmax(beat_counts[_LO_PRIO_BEATS])

        if beat_counts[_LO_PRIO_BEATS][most_lp_beats] > 0:
            y = _LO_PRIO_BEATS[most_lp_beats]
        else:
            y = 0
    return y


def get_heart_rate_label(qrs_indices, fs=None):
    if len(qrs_indices) > 1:
        rr_intervals = np.diff(qrs_indices)
        if fs is not None:
            rr_intervals = rr_intervals / fs
        bpm = 60 / rr_intervals.mean()
        if bpm < 60:
            return _HR_BRADYCARDIA
        elif bpm <= 100:
            return _HR_NORMAL
        else:
            return _HR_TACHYCARDIA
    else:
        return _HR_NOISE


def normalize(array, inplace=False):
    if inplace:
        array -= ds_mean
        array /= ds_std
    else:
        array = (array - ds_mean) / ds_std
    return array


def _choose_random_segment(patients, size=None, segment_p=None):
    num_segments_per_patient = np.array([signal.shape[0] for _, (signal, _) in patients])
    first_segment_index_by_patient = np.cumsum(num_segments_per_patient) - num_segments_per_patient
    num_segments = num_segments_per_patient.sum()
    if segment_p is None:
        p = np.ones(num_segments) / num_segments
    else:
        patient_index, segment_index, segment_prob = segment_p
        p_index = first_segment_index_by_patient[patient_index] + segment_index
        if num_segments <= p_index < 0:
            raise ValueError('The provided patient and segment indices are invalid')
        if 1. < segment_prob < 0.:
            raise ValueError('Probability must lie in the [0, 1] interval')
        p = (1 - segment_prob) * np.ones(num_segments) / (num_segments - 1)
        p[p_index] = segment_prob
    segment_ids = np.random.choice(num_segments, size=size, p=p)
    if size is None:
        patient_index = np.searchsorted(first_segment_index_by_patient, segment_ids, side='right') - 1
        segment_index = segment_ids - first_segment_index_by_patient[patient_index]
        return patient_index, segment_index
    else:
        indices = []
        for segment_id in segment_ids:
            patient_index = np.searchsorted(first_segment_index_by_patient, segment_id, side='right') - 1
            segment_index = segment_id - first_segment_index_by_patient[patient_index]
            indices.append((patient_index, segment_index))
        return indices
