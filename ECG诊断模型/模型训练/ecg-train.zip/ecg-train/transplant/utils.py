import gzip
import pickle

import numpy as np
import pandas as pd


def pad_sequences(x, max_len=None, padding='pre'):
    if max_len is None:
        max_len = max(map(len, x))
    x_shape = x[0].shape
    x_dtype = x[0].dtype
    x_padded = np.zeros((len(x), max_len) + x_shape[1:], dtype=x_dtype)
    for i, x_i in enumerate(x):
        trim_len = min(max_len, len(x_i))
        if padding == 'pre':
            x_padded[i, -trim_len:] = x_i[-trim_len:]
        elif padding == 'post':
            x_padded[i, :trim_len] = x_i[:trim_len]
        else:
            raise ValueError('Unknown padding: %s' % padding)
    return x_padded


def create_predictions_frame(y_prob, y_true=None, y_pred=None, class_names=None, record_ids=None):
    y_prob = np.squeeze(y_prob)
    if y_prob.ndim == 1:  # 二分类
        y_prob = np.stack([1 - y_prob, y_prob], axis=1)
    num_classes = y_prob.shape[1]
    if class_names is None:
        # 使用标签的索引作为类名
        class_names = np.arange(num_classes)
    elif len(class_names) != num_classes:
        raise ValueError('length of class_names does not match with the number of classes')
    columns = ['prob_{}'.format(label) for label in class_names]
    data = {column: y_prob[:, i] for i, column in enumerate(columns)}
    if y_pred is not None:
        y_pred = np.squeeze(y_pred)
        if y_pred.ndim == 1:
            y_pred = np.stack([1 - y_pred, y_pred], axis=1)
        if y_pred.shape != y_prob.shape:
            raise ValueError('y_prob and y_pred shapes do not match')
        y_pred_columns = ['pred_{}'.format(label) for label in class_names]
        y_pred_data = {column: y_pred[:, i] for i, column in enumerate(y_pred_columns)}
        columns = columns + y_pred_columns
        data = {**data, **y_pred_data}
    if y_true is not None:
        y_true = np.squeeze(y_true)
        if y_true.ndim == 1:
            # 搜索与预测矩阵中的任何列都不对应的真实标签
            unknown_labels = np.setdiff1d(y_true, np.arange(num_classes))
            if len(unknown_labels) > 0:
                raise ValueError('Unknown labels encountered: %s' % unknown_labels)
            y_true = np.eye(num_classes)[y_true]
        if y_true.shape != y_prob.shape:
            raise ValueError('y_prob and y_true shapes do not match')
        y_true_columns = ['true_{}'.format(label) for label in class_names]
        y_true_data = {column: y_true[:, i] for i, column in enumerate(y_true_columns)}
        columns = y_true_columns + columns
        data = {**data, **y_true_data}
    predictions_frame = pd.DataFrame(
        data=data,
        columns=columns)
    if record_ids is not None:
        predictions_frame.insert(0, 'record_name', record_ids)
    return predictions_frame


def read_predictions(file):
    df = pd.read_csv(file)
    classes = [label[5:] for label in df.columns if label.startswith('prob')]
    predictions = {}
    for prefix in ['true', 'pred', 'prob']:
        col_names = ['{}_{}'.format(prefix, label) for label in classes]
        col_names = [name for name in col_names if name in df.columns]
        if col_names:
            predictions['y_{}'.format(prefix)] = df[col_names].values
    predictions['classes'] = classes
    return predictions


def matches_spec(o, spec, ignore_batch_dim=False):
    if isinstance(spec, (list, tuple)):
        if not isinstance(o, (list, tuple)):
            raise ValueError('data object is not a list or tuple which is required by the spec: {}'.format(spec))
        if len(spec) != len(o):
            raise ValueError('data object has a different number of elements than the spec: {}'.format(spec))
        for i in range(len(spec)):
            if not matches_spec(o[i], spec[i], ignore_batch_dim=ignore_batch_dim):
                return False
        return True
    elif isinstance(spec, dict):
        if not isinstance(o, dict):
            raise ValueError('data object is not a dict which is required by the spec: {}'.format(spec))
        if spec.keys() != o.keys():
            raise ValueError('data object has different keys than those specified in the spec: {}'.format(spec))
        for k in spec:
            if not matches_spec(o[k], spec[k], ignore_batch_dim=ignore_batch_dim):
                return False
            return True
    else:
        spec_shape = spec.shape[1:] if ignore_batch_dim else spec.shape
        o_shape = o.shape[1:] if ignore_batch_dim else o.shape
        return spec_shape == o_shape and spec.dtype == o.dtype


def running_mean_std(iterator, dtype=None):

    sum_x = np.zeros((), dtype=dtype)
    sum_x2 = np.zeros((), dtype=dtype)
    n = 0
    for x in iterator:
        sum_x += np.sum(x, dtype=dtype)
        sum_x2 += np.sum(x ** 2, dtype=dtype)
        n += x.size
    mean = sum_x / n
    std = np.math.sqrt((sum_x2 / n) - (mean ** 2))
    return mean, std


def buffered_generator(generator, buffer_size):
    buffer = []
    for e in generator:
        buffer.append(e)
        if len(buffer) == buffer_size:
            break
    yield buffer
    for e in generator:
        buffer = buffer[1:] + [e]
        yield buffer


def load_pkl(file, compress=True):
    if compress:
        with gzip.open(file, 'rb') as fh:
            return pickle.load(fh)
    else:
        with open(file, 'rb') as fh:
            return pickle.load(fh)


def save_pkl(file, compress=True, **kwargs):
    if compress:
        with gzip.open(file, 'wb') as fh:
            pickle.dump(kwargs, fh, protocol=4)
    else:
        with open(file, 'wb') as fh:
            pickle.dump(kwargs, fh, protocol=4)


def is_multiclass(labels):
    return labels.squeeze().ndim == 2 and any(labels.sum(axis=1) != 1)
