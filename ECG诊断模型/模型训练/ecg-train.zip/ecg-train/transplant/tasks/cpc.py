import tensorflow as tf

from transplant.modules.attn_pool import AttentionPooling
from transplant.tasks.utils import embed_frames


class CPCSolver(tf.keras.Model):
    def __init__(self, signal_embedding, transformer, **kwargs):
        super().__init__(**kwargs)
        self.signal_embedding = signal_embedding
        self.attn_pooling = AttentionPooling(transformer, keepdims=True)

    def call(self, x, training=None, **kwargs):
        # 提取输入字典中的上下文和样本数据
        context, samples = x['context'], x['samples']
        # 使用信号嵌入模型从上下文帧中提取特征
        context = embed_frames(context, self.signal_embedding)  # (batch_size, context_size, d_model)
        # 将嵌入的上下文帧汇聚为单个上下文向量
        context = self.attn_pooling(context, training=training)  # (batch_size, 1, d_model)
        # 使用信号嵌入模型从样本中提取特征
        samples = embed_frames(samples, self.signal_embedding)  # (batch_size, num_samples, d_model)
        # 计算样本为正样本的可能性分数
        samples = tf.transpose(samples, (0, 2, 1))  # (batch_size, d_model, num_samples)
        scores = tf.matmul(context, samples)
        scores = tf.squeeze(scores, axis=1)
        return scores
