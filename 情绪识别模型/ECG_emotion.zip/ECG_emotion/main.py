import random
from tensorflow.keras.models import load_model
import json
from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
import samplerate
import requests

app = Flask(__name__)

API_KEY = "rak7z2Y9BgpjYoAn3e3DTIxw"
SECRET_KEY = "mBSsPYUEOyY7kPWGYZ9BQ7xNnlth0mRG"


@app.route('/')
def index():
    return render_template('index.html')


def get_access_token():
    url = "https://aip.baidubce.com/oauth/2.0/token"
    params = {"grant_type": "client_credentials", "client_id": API_KEY, "client_secret": SECRET_KEY}
    return str(requests.post(url, params=params).json().get("access_token"))


@app.route('/api/chat', methods=['POST'])
def chat():
    user_input = request.json.get('user_input', '')
    url = "https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/eb-instant?access_token=" + get_access_token()

    payload = json.dumps({
        "messages": [
            {
                "role": "user",
                "content": user_input
            }
        ]
    })
    headers = {
        'Content-Type': 'application/json'
    }

    res = requests.request("POST", url, headers=headers, data=payload).json()
    model_response = res['result']
    print(model_response)
    return jsonify({'model_response': model_response})


# # 加载保存的模型

@app.route('/api/emotion', methods=['POST'])
def emotion_post_api():
    data = request.get_json()
    fs = data['fs']
    sig = data['sig']
    sig = np.array(sig)
    loaded_model = load_model('model_fully_supervised')
    loaded_scaler = joblib.load('scaler.pkl')
    # if fs != 300:
    #     fs_ratio = 300 / fs  # 计算重采样比例
    #     sig = samplerate.resample(sig, fs_ratio)
    # if len(sig) < 2560:
    #     sig = np.pad(sig, (2560 - len(sig), 0), 'constant', constant_values=(0, 0))
    start_index = random.randint(0, len(sig) - 2560)
    sample = sig[start_index:start_index + 2560]
    sample = sample.reshape(1, -1)
    new_sample = loaded_scaler.transform(sample)
    # # 使用加载的模型对单个样本进行预测
    prediction = loaded_model.predict(new_sample)
    prediction = prediction[0].tolist()
    ans = ""
    pos = prediction.index(max(prediction))
    if pos == 0:
        ans = "你的情绪很平稳哦，祝你这一天心情愉快！"
    elif pos == 1:
        ans = "看起来你很开心哦，祝你能一直保持一个好心情！"
    else:
        ans = "你的压力指数为,看起来你有点焦虑呢，快来和我聊聊天，缓解心情吧！"
    json_data = {'msg': ans, 'score': prediction[2] * 100}
    return jsonify(json_data)

if __name__ == '__main__':
    app.run(debug=True)



if __name__ == '__main__':
    app.run(debug=True)
