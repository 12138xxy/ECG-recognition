import os
import gc

import pandas as pd
import numpy as np
import tensorflow as tf

from tensorflow import keras
from tensorflow.keras import layers

import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import LeaveOneGroupOut, LeavePGroupsOut

from matplotlib import pyplot as plt
from tensorflow.keras.models import load_model

# Define train and test sets
train_participants = ['S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10']
devel_participants = ['S11', 'S13', 'S14']
test_participants = [ 'S15', 'S16','S17']


def class_to_number(labels):
    # 类转数字

    classes = np.unique(labels)

    for c in range(len(classes)):
        labels[labels == classes[c]] = c

    return np.array(labels, dtype=int)


def one_hot_encoding(labels, num_classes):
    # 对标签热编码

    if type(labels[0]) == str:
        labels = class_to_number(labels)

    elif type(labels[0]) == float:
        labels = int(labels)

    Y = np.eye(num_classes)[labels]

    return Y


def read_data(participants):
    # This function reads the data according to participants list taken as an argument

    X = []

    for filename in participants:
        temp = pd.read_csv('data/{}.csv'.format(filename), index_col=0)
        X.append(temp)

    X = pd.concat(X, axis=0)
    y = X.lab.to_numpy()
    y = class_to_number(y)
    X = X.iloc[:, 2:].to_numpy()

    return X, y


def hor_filp(signal):
    # 水平翻转
    hor_flipped = np.flip(signal)
    return hor_flipped


def add_noise_with_SNR(signal, noise_amount):
    # 添加一定信噪比（SNR）的噪声
    target_snr_db = noise_amount  # 目标信噪比
    x_watts = signal ** 2  # 计算信号功率并转换为分贝
    sig_avg_watts = np.mean(x_watts)
    sig_avg_db = 10 * np.log10(sig_avg_watts)  # 计算噪声然后转换为瓦特
    noise_avg_db = sig_avg_db - target_snr_db
    noise_avg_watts = 10 ** (noise_avg_db / 10)
    mean_noise = 0
    noise_volts = np.random.normal(mean_noise, np.sqrt(noise_avg_watts),
                                   len(x_watts))  # 生成白噪声样本
    noised_signal = signal + noise_volts  # 添加噪声后的信号
    return noised_signal


def scaled(signal, factor):
    # 缩放
    scaled_signal = signal * factor
    return scaled_signal


def transform_data(X):
    # 执行上面定义的转换并创建人工标签
    X_noised = np.zeros(X.shape)
    X_scaled = np.zeros(X.shape)
    X_flipped = np.zeros(X.shape)

    for i in range(X.shape[0]):
        X_noised[i, :] = add_noise_with_SNR(X[i, :], 20)
        X_scaled[i, :] = scaled(X[i, :], 1.1)
        X_flipped[i, :] = hor_filp(X[i, :])

    full_data = np.concatenate((X, X_noised, X_scaled, X_flipped))
    full_labels = np.concatenate((np.full(X.shape[0], 0),
                                  np.full(X.shape[0], 1),
                                  np.full(X.shape[0], 2),
                                  np.full(X.shape[0], 3)))

    return full_data, full_labels


def create_graph(input_shape=2560, num_classes=3):
    inputs = keras.Input(shape=(input_shape, 1))

    # Conv1
    x = layers.Conv1D(filters=32, kernel_size=32, strides=1)(inputs)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.Conv1D(filters=32, kernel_size=32, strides=1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.MaxPooling1D(pool_size=8, strides=2)(x)

    # Conv2
    x = layers.Conv1D(filters=64, kernel_size=16, strides=1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.Conv1D(filters=64, kernel_size=16, strides=1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.GlobalMaxPooling1D()(x)
    x = layers.Flatten()(x)

    # Head
    x = layers.Dense(128)(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Activation(layers.LeakyReLU())(x)
    outputs = layers.Dense(num_classes, 'softmax')(x)

    return inputs, outputs

# 读取训练和测试参与者的文件
X_train, y_train = read_data(train_participants)

X_devel, y_devel = read_data(devel_participants)
X_test, y_test = read_data(test_participants)
# 标准化数据
scaler = StandardScaler()
X_train_norm = scaler.fit_transform(X_train)
X_devel_norm = scaler.transform(X_devel)
X_test_norm = scaler.transform(X_test)
joblib.dump(scaler, 'scaler.pkl')


# 将标签转换为独热编码
y_train_one_hot = one_hot_encoding(y_train, 3)
y_devel_one_hot = one_hot_encoding(y_devel, 3)
y_test_one_hot = one_hot_encoding(y_test, 3)

# 转换数据并获取人工标签
X_train_transformed, y_train_transformed = transform_data(X_train_norm)
X_devel_transformed, y_devel_transformed = transform_data(X_devel_norm)

# 对标签进行独热编码
y_train_transformed_one_hot = one_hot_encoding(y_train_transformed, 4)
y_devel_transformed_one_hot = one_hot_encoding(y_devel_transformed, 4)

# 创建模型
inputs, outputs = create_graph(input_shape=2560, num_classes=4)
model_pretext = keras.Model(inputs, outputs)

# 定义优化器和回调（在开发集的损失不再减少时停止训练）
opt = keras.optimizers.Adam(lr=0.001)
callback = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# # 编译和拟合模型
model_pretext.compile(optimizer=opt, loss='categorical_crossentropy')
history = model_pretext.fit(X_train_transformed, y_train_transformed_one_hot, validation_data=(X_devel_transformed, y_devel_transformed_one_hot),
                            callbacks=[callback], epochs=100, batch_size=32, verbose=1)

# # 绘制训练和验证损失曲线
# plt.plot(history.history['loss'])
# plt.plot(history.history['val_loss'])
# plt.show()

# # 堆叠图层
x = layers.Dense(128)(model_pretext.layers[-5].output)
x = layers.Dropout(0.5)(x)
x = layers.Activation(layers.LeakyReLU())(x)
outputs_downstream = layers.Dense(3, 'softmax')(x)

# 创建下游任务的模型
model_downstream = keras.Model(inputs, outputs_downstream)

# 冻结预训练模型的层，只训练添加的额外层
for i in range(len(model_downstream.layers)-5):
    model_downstream.layers[i].trainable = False

# 定义优化器和回调（在开发集的损失不再减少时停止训练）
opt = keras.optimizers.Adam(lr=0.001)
callback = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# 编译和拟合下游任务模型
model_downstream.compile(optimizer=opt, loss='categorical_crossentropy')
history = model_downstream.fit(X_train_norm, y_train_one_hot, validation_data=(X_devel_norm, y_devel_one_hot), callbacks=[callback], epochs=100, batch_size=32, verbose=2)

# 绘制训练和验证损失曲线
plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.show()

# 使用模型对测试集进行预测
pred_downstream = model_downstream.predict(X_test_norm)

# 打印模型在测试集上的性能指标
print('Accuracy\t{}'.format(np.round(accuracy_score(np.argmax(pred_downstream, axis=1), y_test),3)))
print('F1 score\t{}'.format(np.round(f1_score(np.argmax(pred_downstream, axis=1), y_test, average='macro'),3)))
print('UAR\t\t{}'.format(np.round(recall_score(np.argmax(pred_downstream, axis=1), y_test, average='macro'),3)))
model_downstream.save('saved_model_downstream')