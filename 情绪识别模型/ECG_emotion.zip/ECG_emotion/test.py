import requests
import json
import scipy.io as sio
import pandas as pd

api_url = 'http://47.120.36.167:5656/api/emotion'
# 发送 GET 请求
# sig = sio.loadmat('A00021.mat')['val'][0].astype('float')
data = pd.read_csv('data/S17.csv')
sig = data.iloc[199, 3:]
json_data = {'fs': 300, 'sig': sig.tolist()}
# json_data = {'user_input': '你好，请问什么是心脏病'}
headers = {"Content-Type": "application/json",
           "Connection": "close"}
response_post = requests.post(api_url, json=json_data, headers=headers)
if response_post.status_code == 200:
    try:
        # 尝试解析 JSON 响应
        json_data = response_post.json()
        print('GET Response:', json_data)
    except requests.exceptions.JSONDecodeError:
        print('Error decoding JSON: Empty response or invalid JSON format')
else:
    print(f'Error: {response_post.status_code} - {response_post.text}')
