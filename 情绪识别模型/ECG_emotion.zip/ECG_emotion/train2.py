import pandas as pd
import numpy as np
import tensorflow as tf

from tensorflow import keras
from tensorflow.keras import layers

import joblib
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, recall_score, f1_score, confusion_matrix
from sklearn.model_selection import LeaveOneGroupOut, LeavePGroupsOut

from matplotlib import pyplot as plt


def class_to_number(labels):
    # 将类别转换为数字
    classes = np.unique(labels)

    for c in range(len(classes)):
        labels[labels == classes[c]] = c

    return np.array(labels, dtype=int)


def one_hot_encoding(labels, num_classes):
    # 对标签进行独热编码

    if type(labels[0]) == str:
        labels = class_to_number(labels)

    elif type(labels[0]) == float:
        labels = int(labels)

    Y = np.eye(num_classes)[labels]

    return Y


def read_data(participants):
    # 根据参与者列表读取数据

    X = []

    for filename in participants:
        temp = pd.read_csv('data/{}.csv'.format(filename), index_col=0)
        X.append(temp)

    X = pd.concat(X, axis=0)
    y = X.lab.to_numpy()
    y = class_to_number(y)
    X = X.iloc[:, 2:].to_numpy()

    return X, y

# 定义训练和测试集
train_participants = ['S2', 'S3', 'S4', 'S5', 'S6', 'S7', 'S8', 'S9', 'S10']
devel_participants = ['S11', 'S13', 'S14']
test_participants  = ['S15', 'S16', 'S17']

# 读取训练和测试参与者的文件
X_train, y_train = read_data(train_participants)
X_devel, y_devel = read_data(devel_participants)
X_test, y_test = read_data(test_participants)

# 标准化数据
scaler = StandardScaler()
X_train_norm = scaler.fit_transform(X_train)
X_devel_norm = scaler.transform(X_devel)
X_test_norm  = scaler.transform(X_test)

# 将标签转换为独热编码
y_train_one_hot = one_hot_encoding(y_train, 3)
y_devel_one_hot = one_hot_encoding(y_devel, 3)
y_test_one_hot = one_hot_encoding(y_test, 3)

def create_graph(input_shape=2560, num_classes=3):
    inputs = keras.Input(shape=(input_shape, 1))

    # 卷积层1
    x = layers.Conv1D(filters=32, kernel_size=32, strides=1)(inputs)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.Conv1D(filters=32, kernel_size=32, strides=1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.MaxPooling1D(pool_size=8, strides=2)(x)

    # 卷积层2
    x = layers.Conv1D(filters=64, kernel_size=16, strides=1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.Conv1D(filters=64, kernel_size=16, strides=1)(x)
    x = layers.BatchNormalization()(x)
    x = layers.Activation(layers.LeakyReLU())(x)

    x = layers.GlobalMaxPooling1D()(x)
    x = layers.Flatten()(x)

    # 头部
    x = layers.Dense(128)(x)
    x = layers.Dropout(0.5)(x)
    x = layers.Activation(layers.LeakyReLU())(x)
    outputs = layers.Dense(num_classes, 'softmax')(x)

    return inputs, outputs



# 创建模型
inputs, outputs = create_graph(input_shape=2560, num_classes=3)
model_fully_supervised = keras.Model(inputs, outputs)

# 定义优化器和回调
opt = keras.optimizers.Adam(lr=0.001)
callback = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# 拟合模型
model_fully_supervised.compile(optimizer=opt, loss='categorical_crossentropy')
history_fs = model_fully_supervised.fit(X_train_norm, y_train_one_hot, validation_data=(X_devel_norm, y_devel_one_hot),
                                        callbacks=[callback], epochs=100, batch_size=32, verbose=2)
pred_fully_supervised = model_fully_supervised.predict(X_test_norm)
print('Accuracy\t{}'.format(np.round(accuracy_score(np.argmax(pred_fully_supervised, axis=1), y_test),3)))
print('F1 score\t{}'.format(np.round(f1_score(np.argmax(pred_fully_supervised, axis=1), y_test, average='macro'),3)))
print('UAR\t\t{}'.format(np.round(recall_score(np.argmax(pred_fully_supervised, axis=1), y_test, average='macro'),3)))
model_fully_supervised.save('model_fully_supervised')